此目录用于存放产品/设备操作相关的手册文档（HTML/PDF等）。
当前将迁移：
- manual-qr-a5.html
- manual-qr-a5-final.html